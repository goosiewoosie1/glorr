const ref = {
    nameinput: document.getElementById('name'),
    menu: document.getElementById('menu'),
    gui: document.querySelector('.gui'),
    chatDiv: document.querySelector('.chatDiv'),
    chat: document.querySelector('.chat'),
    chatMessageDiv: document.querySelector('.chat-div'),
    canvas: document.getElementById('canvas'),
}